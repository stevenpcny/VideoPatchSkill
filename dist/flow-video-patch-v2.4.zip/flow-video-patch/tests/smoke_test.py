#!/usr/bin/env python3
"""One-command behavioral verification with disposable, synthetic media only."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import flow_patch as fp


def cli(*args, ok=True):
    p = subprocess.run([sys.executable,str(ROOT/'scripts/flow_patch.py'),*map(str,args)],
                       stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    if ok and p.returncode:
        raise AssertionError(p.stdout+p.stderr)
    if not ok and not p.returncode:
        raise AssertionError('Unexpected success')
    return p


def encode(path, images, audio=None):
    h,w = images[0].shape[:2]
    cmd = [fp.FFMPEG,'-v','error','-n','-f','rawvideo','-pix_fmt','bgr24','-s',f'{w}x{h}',
           '-r','24','-i','-']
    if audio:
        cmd += ['-i',str(audio),'-map','0:v:0','-map','1:a:0','-c:a','copy']
    cmd += ['-c:v','libx264','-crf','10','-pix_fmt','yuv420p',str(path)]
    subprocess.run(cmd,input=b''.join(im.tobytes() for im in images),check=True,
                   stdout=subprocess.PIPE,stderr=subprocess.PIPE)


def image(path,index):
    reader = fp.Reader(path,fp.probe(path)['size'])
    try:
        return reader.get(index).copy()
    finally:
        reader.close()


class Smoke(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix='flow-patch-smoke-')
        cls.base = Path(cls.tmp.name)
        audio = cls.base/'tone.m4a'
        fp.run([fp.FFMPEG,'-v','error','-n','-f','lavfi','-i','sine=frequency=440:sample_rate=48000',
                '-t','1','-c:a','aac',audio])
        # Stable textured background and a deliberately distinct mouth rectangle.
        rng = np.random.default_rng(42)
        texture = rng.integers(30,180,(128,192,3),dtype=np.uint8)
        frames=[]
        for i in range(24):
            im=texture.copy(); im[8:24,8+i:24+i]=[30,200,50]
            im[75:91,25:71]=[180,40,40];frames.append(im)
        cls.source=cls.base/'source 中文.mp4';encode(cls.source,frames,audio)
        cls.generated=cls.base/'flow.mp4'
        generated=[]
        for i in range(23):
            im=frames[i][:,:96].copy(); im[25:65,25:71]=[40,70,220]
            # Generation also changes the mouth; upper-face route must not use it.
            im[75:91,25:71]=[20,220,220]; generated.append(im)
        encode(cls.generated,generated)
        cls.cfg=dict(schema_version=1,source=str(cls.source),source_size=[192,128],fps=24)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def config(self,name,**updates):
        cfg=json.loads(json.dumps(self.cfg));cfg.update(updates)
        path=self.base/(name+'.json');path.write_text(json.dumps(cfg),encoding='utf-8')
        return path

    def patch(self,**updates):
        p=dict(generated=str(self.generated),target=[0,24],frame_map=list(range(23))+[22],
               crop=[0,0,96,128],work_size=[96,128],matte=dict(region=[16,16,64,96],
               feather=8,protect=[[16,72,64,24]]),blend='alpha',fade_frames=0)
        p.update(updates);return p

    def test_01_doctor_and_inspect(self):
        cli('doctor')
        self.assertEqual(json.loads(cli('inspect','--source',self.source).stdout)['frames'],24)

    def test_02_prepare_context_and_tracked_crop(self):
        cfg=self.config('prepare',prepare=dict(core=[4,20],context_frames=2,
                        crop=[dict(frame=0,value=[0,0,96,128]),dict(frame=23,value=[24,0,96,128])],
                        output_size=[96,128],mask_regions=[[24,24,32,40]],color_rgb=[0,0,0]))
        out=self.base/'upload.mp4'
        cli('prepare','--config',cfg,'--output',out,'--dry-run')
        self.assertFalse(out.exists())
        cli('prepare','--config',cfg,'--output',out)
        rpt=json.loads(out.with_suffix('.report.json').read_text())
        self.assertEqual(rpt['output']['frames'],20)
        self.assertEqual(rpt['output']['core_in_upload'],[2,18])
        self.assertLess(image(out,5)[30:55,30:50].mean(),8)
        self.assertGreater(image(out,0)[30:55,30:50].mean(),30)
        self.assertTrue(rpt['decode_pass'])

    def test_03_protected_mouth_audio_and_tail_hold(self):
        cfg=self.config('upper',patches=[self.patch()]);out=self.base/'upper.mp4'
        cli('merge','--config',cfg,'--output',out)
        before,after=image(self.source,12),image(out,12)
        self.assertGreater(np.mean(abs(after[30:60,30:65].astype(float)-before[30:60,30:65])),20)
        self.assertLess(np.mean(abs(after[78:88,30:65].astype(float)-before[78:88,30:65])),5)
        self.assertEqual(fp.audio_hash(self.source),fp.audio_hash(out))
        self.assertEqual(fp.probe(out)['frames'],24)
        rejected=cli('merge','--config',cfg,'--output',out,ok=False)
        self.assertIn('exists',rejected.stderr)

    def test_04_multiband_two_people(self):
        p=self.patch(matte=dict(region=[8,8,80,112],feather=8),blend='multiband',levels=3)
        q=json.loads(json.dumps(p));q['crop']=[96,0,96,128]
        cfg=self.config('both',patches=[p,q]);out=self.base/'both.mp4'
        cli('merge','--config',cfg,'--output',out)
        before,after=image(self.source,10),image(out,10)
        for x in (0,96):
            self.assertGreater(np.mean(abs(after[30:60,x+30:x+65].astype(float)-
                                           before[30:60,x+30:x+65])),15)
        self.assertEqual(fp.audio_hash(self.source),fp.audio_hash(out))

    def test_05_missing_frame_original_fallback(self):
        p=self.patch();p['frame_map'][10]=None
        cfg=self.config('fallback',patches=[p]);out=self.base/'fallback.mp4'
        cli('merge','--config',cfg,'--output',out)
        before,after=image(self.source,10),image(out,10)
        self.assertLess(np.mean(abs(after.astype(float)-before)),5)

    def test_06_reject_unmapped_short_and_overlap(self):
        p=self.patch();p.pop('frame_map')
        cfg=self.config('short',patches=[p]);out=self.base/'bad.mp4'
        self.assertIn('Mapped generated frame missing',cli('merge','--config',cfg,'--output',out,ok=False).stderr)
        p=self.patch();cfg=self.config('overlap',patches=[p,p])
        self.assertIn('overlap',cli('merge','--config',cfg,'--output',out,ok=False).stderr)
        self.assertFalse(out.exists())

    def test_07_fit_known_translation_and_fixed_color(self):
        # Known geometry and fixed color offset, not a real Flow render.
        original=[image(self.source,i)[:,:96].copy() for i in range(24)]
        gen=[cv2.warpAffine(np.clip(im.astype(float)*.9+7,0,255).astype(np.uint8),
                           np.array([[1,0,2],[0,1,1]],np.float32),(96,128)) for im in original]
        gp=self.base/'fit-flow.mp4';encode(gp,gen)
        p=self.patch(generated=str(gp),frame_map=list(range(24)),
                     matte=dict(region=[24,24,48,48],feather=6),blend='alpha')
        cfg=self.config('fit',patches=[p]);out=self.base/'fit-proposed.json'
        result=subprocess.run([sys.executable,str(ROOT/'scripts/fit_patch.py'),'--config',str(cfg),
                               '--output',str(out)],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        proposed=json.loads(out.read_text())
        self.assertTrue(all(r['accepted'] for r in proposed['fit_review']['registration']))
        for row in proposed['patches'][0]['source_to_generated_affine']:
            self.assertLess(abs(row['value'][2]-2),.6)
            self.assertLess(abs(row['value'][5]-1),.6)
        self.assertTrue(proposed['fit_review']['color']['applied'])
        proposed_path=self.base/'fit-merged.mp4'
        cli('merge','--config',out,'--output',proposed_path)

    def test_08_prepare_no_audio_at_source_boundary(self):
        cfg=self.config('no-audio',source=str(self.generated),source_size=[96,128],
                        prepare=dict(core=[0,10],context_frames=24,crop=[0,0,96,128],
                                     output_size=[96,128],mask_regions=[[24,24,32,40]]))
        out=self.base/'no-audio-upload.mp4'
        cli('prepare','--config',cfg,'--output',out)
        rpt=json.loads(out.with_suffix('.report.json').read_text())
        self.assertEqual(rpt['output']['frames'],23)
        self.assertEqual(rpt['output']['core_in_upload'],[0,10])
        self.assertFalse(rpt['output']['audio'])


if __name__=='__main__':
    unittest.main(verbosity=2)
